
import React from 'react';


function Login() {
  return (
    <div>
      <h2>Login</h2>
    </div>
  );
}

export default Login;
